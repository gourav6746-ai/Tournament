import { createContext, useContext, useState, type ReactNode } from "react";

type User = {
  email: string;
  name: string;
  isAdmin: boolean;
};

type AuthContextType = {
  user: User | null;
  login: (email: string, password: string) => { success: boolean; message: string; isAdmin: boolean };
  signup: (name: string, email: string, password: string) => { success: boolean; message: string };
  logout: () => void;
  registeredUsers: RegisteredUser[];
  tournaments: TournamentData[];
  addTournament: (t: TournamentData) => void;
  deleteTournament: (id: number) => void;
  updateTournament: (t: TournamentData) => void;
  announcements: Announcement[];
  addAnnouncement: (a: Announcement) => void;
  deleteAnnouncement: (id: number) => void;
};

export type RegisteredUser = {
  name: string;
  email: string;
  password: string;
  joinedAt: string;
};

export type TournamentData = {
  id: number;
  game: string;
  title: string;
  prizePool: string;
  entryFee: string;
  maxPlayers: string;
  currentPlayers: string;
  status: "live" | "upcoming" | "filling" | "completed";
  mode: string;
  map: string;
  time: string;
};

export type Announcement = {
  id: number;
  title: string;
  message: string;
  type: "info" | "warning" | "success";
  createdAt: string;
};

const ADMIN_EMAIL = "gourav6746@gmail.com";
const ADMIN_PASSWORD = "pandit_shiv6736";

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [registeredUsers, setRegisteredUsers] = useState<RegisteredUser[]>([
    { name: "Rahul Gamer", email: "rahul@gmail.com", password: "123456", joinedAt: "2025-01-15" },
    { name: "Priya Pro", email: "priya@gmail.com", password: "123456", joinedAt: "2025-01-20" },
    { name: "Amit FF King", email: "amit@gmail.com", password: "123456", joinedAt: "2025-02-01" },
    { name: "Sneha Queen", email: "sneha@gmail.com", password: "123456", joinedAt: "2025-02-10" },
    { name: "Vikram PUBG", email: "vikram@gmail.com", password: "123456", joinedAt: "2025-02-18" },
  ]);

  const [tournaments, setTournaments] = useState<TournamentData[]>([
    { id: 1, game: "Free Fire", title: "Free Fire MAX - Squad Showdown", prizePool: "₹10,000", entryFee: "FREE", maxPlayers: "100", currentPlayers: "88", status: "live", mode: "Squad", map: "Bermuda", time: "LIVE NOW" },
    { id: 2, game: "PUBG Mobile", title: "PUBG Classic - Erangel Battle", prizePool: "₹25,000", entryFee: "₹50", maxPlayers: "100", currentPlayers: "72", status: "live", mode: "Squad", map: "Erangel", time: "LIVE NOW" },
    { id: 3, game: "Free Fire", title: "Free Fire Solo Sniper Challenge", prizePool: "₹5,000", entryFee: "₹20", maxPlayers: "50", currentPlayers: "42", status: "filling", mode: "Solo", map: "Kalahari", time: "45 min" },
    { id: 4, game: "PUBG Mobile", title: "PUBG Duo - Miramar Madness", prizePool: "₹15,000", entryFee: "₹30", maxPlayers: "100", currentPlayers: "56", status: "upcoming", mode: "Duo", map: "Miramar", time: "1 hr" },
  ]);

  const [announcements, setAnnouncements] = useState<Announcement[]>([
    { id: 1, title: "Season 5 Live! 🔥", message: "Season 5 ab shuru ho gaya hai! Naye rewards, naye challenges!", type: "success", createdAt: "2025-03-01" },
    { id: 2, title: "Server Maintenance ⚠️", message: "Kal raat 2 baje se 4 baje tak server maintenance hoga.", type: "warning", createdAt: "2025-03-05" },
  ]);

  const login = (email: string, password: string) => {
    // Admin check
    if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
      setUser({ email, name: "Admin Gourav", isAdmin: true });
      return { success: true, message: "Admin login successful!", isAdmin: true };
    }

    // Regular user check
    const found = registeredUsers.find(u => u.email === email && u.password === password);
    if (found) {
      setUser({ email: found.email, name: found.name, isAdmin: false });
      return { success: true, message: "Login successful!", isAdmin: false };
    }

    return { success: false, message: "Galat email ya password! Dobara try karo.", isAdmin: false };
  };

  const signup = (name: string, email: string, password: string) => {
    const exists = registeredUsers.find(u => u.email === email);
    if (exists) {
      return { success: false, message: "Ye email already registered hai! Login karo." };
    }
    const newUser: RegisteredUser = {
      name,
      email,
      password,
      joinedAt: new Date().toISOString().split("T")[0],
    };
    setRegisteredUsers(prev => [...prev, newUser]);
    setUser({ email, name, isAdmin: false });
    return { success: true, message: "Account successfully ban gaya! 🎉" };
  };

  const logout = () => setUser(null);

  const addTournament = (t: TournamentData) => setTournaments(prev => [...prev, t]);
  const deleteTournament = (id: number) => setTournaments(prev => prev.filter(t => t.id !== id));
  const updateTournament = (updated: TournamentData) => setTournaments(prev => prev.map(t => t.id === updated.id ? updated : t));

  const addAnnouncement = (a: Announcement) => setAnnouncements(prev => [...prev, a]);
  const deleteAnnouncement = (id: number) => setAnnouncements(prev => prev.filter(a => a.id !== id));

  return (
    <AuthContext.Provider value={{
      user, login, signup, logout,
      registeredUsers, tournaments,
      addTournament, deleteTournament, updateTournament,
      announcements, addAnnouncement, deleteAnnouncement,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
