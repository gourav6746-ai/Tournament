import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth, type TournamentData, type Announcement } from "../context/AuthContext";
import {
  Gamepad2, Users, Trophy, LayoutDashboard, Megaphone, LogOut,
  Plus, Trash2, Edit3, X, Shield, TrendingUp, DollarSign,
  Menu, ChevronRight, Eye, Calendar, Flame, Bell, Settings
} from "lucide-react";

type Tab = "dashboard" | "tournaments" | "users" | "announcements" | "settings";

export function AdminPanel() {
  const { user, logout, registeredUsers, tournaments, addTournament, deleteTournament, updateTournament, announcements, addAnnouncement, deleteAnnouncement } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<Tab>("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Tournament form
  const [showTournamentForm, setShowTournamentForm] = useState(false);
  const [editingTournament, setEditingTournament] = useState<TournamentData | null>(null);
  const [tForm, setTForm] = useState({ game: "Free Fire", title: "", prizePool: "", entryFee: "", maxPlayers: "100", mode: "Squad", map: "Bermuda", time: "", status: "upcoming" as TournamentData["status"] });

  // Announcement form
  const [showAnnouncementForm, setShowAnnouncementForm] = useState(false);
  const [aForm, setAForm] = useState({ title: "", message: "", type: "info" as Announcement["type"] });

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  if (!user || !user.isAdmin) {
    navigate("/login");
    return null;
  }

  const resetTForm = () => {
    setTForm({ game: "Free Fire", title: "", prizePool: "", entryFee: "", maxPlayers: "100", mode: "Squad", map: "Bermuda", time: "", status: "upcoming" });
    setEditingTournament(null);
    setShowTournamentForm(false);
  };

  const handleSaveTournament = () => {
    if (!tForm.title || !tForm.prizePool || !tForm.time) return;
    if (editingTournament) {
      updateTournament({ ...editingTournament, ...tForm });
    } else {
      addTournament({
        id: Date.now(),
        ...tForm,
        currentPlayers: "0",
      });
    }
    resetTForm();
  };

  const handleEditTournament = (t: TournamentData) => {
    setEditingTournament(t);
    setTForm({ game: t.game, title: t.title, prizePool: t.prizePool, entryFee: t.entryFee, maxPlayers: t.maxPlayers, mode: t.mode, map: t.map, time: t.time, status: t.status });
    setShowTournamentForm(true);
  };

  const handleSaveAnnouncement = () => {
    if (!aForm.title || !aForm.message) return;
    addAnnouncement({
      id: Date.now(),
      ...aForm,
      createdAt: new Date().toISOString().split("T")[0],
    });
    setAForm({ title: "", message: "", type: "info" });
    setShowAnnouncementForm(false);
  };

  const liveTournaments = tournaments.filter(t => t.status === "live").length;
  const totalPrize = tournaments.reduce((sum, t) => {
    const num = parseInt(t.prizePool.replace(/[₹,]/g, "")) || 0;
    return sum + num;
  }, 0);

  const sidebarItems: { id: Tab; icon: typeof LayoutDashboard; label: string }[] = [
    { id: "dashboard", icon: LayoutDashboard, label: "Dashboard" },
    { id: "tournaments", icon: Trophy, label: "Tournaments" },
    { id: "users", icon: Users, label: "Users" },
    { id: "announcements", icon: Megaphone, label: "Announcements" },
    { id: "settings", icon: Settings, label: "Settings" },
  ];

  return (
    <div className="min-h-screen bg-dark-bg flex">
      {/* Sidebar Overlay Mobile */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/60 z-40 lg:hidden" onClick={() => setSidebarOpen(false)}></div>
      )}

      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 z-50 w-64 bg-dark-card border-r border-dark-border flex flex-col transition-transform lg:translate-x-0 ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}`}>
        {/* Logo */}
        <div className="flex items-center gap-2 p-5 border-b border-dark-border">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-neon-green to-neon-blue">
            <Gamepad2 className="h-6 w-6 text-dark-bg" />
          </div>
          <div>
            <div className="text-lg font-extrabold text-white">BATTLE<span className="text-neon-green">ZONE</span></div>
            <div className="flex items-center gap-1 text-xs text-neon-purple">
              <Shield className="h-3 w-3" /> Admin Panel
            </div>
          </div>
        </div>

        {/* Nav Items */}
        <nav className="flex-1 p-4 space-y-1">
          {sidebarItems.map(item => (
            <button
              key={item.id}
              onClick={() => { setActiveTab(item.id); setSidebarOpen(false); }}
              className={`w-full flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium transition-all ${
                activeTab === item.id
                  ? "bg-neon-green/10 text-neon-green border border-neon-green/20"
                  : "text-gray-400 hover:text-white hover:bg-dark-bg/50"
              }`}
            >
              <item.icon className="h-5 w-5" />
              {item.label}
              {activeTab === item.id && <ChevronRight className="h-4 w-4 ml-auto" />}
            </button>
          ))}
        </nav>

        {/* Admin Info */}
        <div className="p-4 border-t border-dark-border">
          <div className="flex items-center gap-3 mb-3">
            <div className="h-10 w-10 rounded-full bg-gradient-to-br from-neon-green to-neon-blue flex items-center justify-center text-dark-bg font-bold text-sm">AG</div>
            <div>
              <div className="text-sm font-bold text-white">{user.name}</div>
              <div className="text-xs text-gray-500 truncate">{user.email}</div>
            </div>
          </div>
          <button onClick={handleLogout} className="w-full flex items-center justify-center gap-2 rounded-xl bg-neon-red/10 border border-neon-red/20 py-2.5 text-sm font-semibold text-neon-red hover:bg-neon-red/20 transition">
            <LogOut className="h-4 w-4" /> Logout
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        {/* Top Bar */}
        <header className="sticky top-0 z-30 flex items-center justify-between border-b border-dark-border bg-dark-bg/90 backdrop-blur-xl px-4 sm:px-6 py-4">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 text-gray-400 hover:text-white">
              <Menu className="h-6 w-6" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-white capitalize">{activeTab === "dashboard" ? "📊 Dashboard" : activeTab === "tournaments" ? "🏆 Tournaments Manage" : activeTab === "users" ? "👥 Users Manage" : activeTab === "announcements" ? "📢 Announcements" : "⚙️ Settings"}</h1>
              <p className="text-xs text-gray-500">Welcome back, Admin Gourav! 🎮</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button className="relative p-2 rounded-lg text-gray-400 hover:text-white hover:bg-dark-card transition">
              <Bell className="h-5 w-5" />
              <span className="absolute top-1 right-1 h-2 w-2 rounded-full bg-neon-red"></span>
            </button>
          </div>
        </header>

        <div className="p-4 sm:p-6 lg:p-8">
          {/* DASHBOARD TAB */}
          {activeTab === "dashboard" && (
            <div className="space-y-6">
              {/* Stats Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { title: "Total Users", value: registeredUsers.length.toString(), icon: Users, color: "text-neon-blue", bgColor: "bg-neon-blue/10", borderColor: "border-neon-blue/20", change: "+12%" },
                  { title: "Total Tournaments", value: tournaments.length.toString(), icon: Trophy, color: "text-neon-green", bgColor: "bg-neon-green/10", borderColor: "border-neon-green/20", change: "+8%" },
                  { title: "Live Now", value: liveTournaments.toString(), icon: Flame, color: "text-neon-red", bgColor: "bg-neon-red/10", borderColor: "border-neon-red/20", change: "Active" },
                  { title: "Total Prize Pool", value: `₹${totalPrize.toLocaleString()}`, icon: DollarSign, color: "text-neon-yellow", bgColor: "bg-neon-yellow/10", borderColor: "border-neon-yellow/20", change: "+25%" },
                ].map(stat => (
                  <div key={stat.title} className={`rounded-2xl border ${stat.borderColor} bg-dark-card p-5 hover:bg-dark-card-hover transition`}>
                    <div className="flex items-center justify-between mb-3">
                      <div className={`h-10 w-10 rounded-xl ${stat.bgColor} flex items-center justify-center`}>
                        <stat.icon className={`h-5 w-5 ${stat.color}`} />
                      </div>
                      <span className="flex items-center gap-1 text-xs font-semibold text-neon-green">
                        <TrendingUp className="h-3 w-3" /> {stat.change}
                      </span>
                    </div>
                    <div className="text-2xl font-black text-white">{stat.value}</div>
                    <div className="text-xs text-gray-500 font-medium">{stat.title}</div>
                  </div>
                ))}
              </div>

              {/* Recent Users & Tournaments */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Recent Users */}
                <div className="rounded-2xl border border-dark-border bg-dark-card p-5">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                      <Users className="h-5 w-5 text-neon-blue" /> Recent Users
                    </h3>
                    <button onClick={() => setActiveTab("users")} className="text-xs text-neon-green hover:text-neon-green/80">View All →</button>
                  </div>
                  <div className="space-y-3">
                    {registeredUsers.slice(-5).reverse().map(u => (
                      <div key={u.email} className="flex items-center justify-between rounded-xl bg-dark-bg/50 p-3">
                        <div className="flex items-center gap-3">
                          <div className="h-8 w-8 rounded-full bg-gradient-to-br from-neon-purple to-neon-blue flex items-center justify-center text-white text-xs font-bold">
                            {u.name.charAt(0)}
                          </div>
                          <div>
                            <div className="text-sm font-semibold text-white">{u.name}</div>
                            <div className="text-xs text-gray-500">{u.email}</div>
                          </div>
                        </div>
                        <span className="text-xs text-gray-500">{u.joinedAt}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Recent Tournaments */}
                <div className="rounded-2xl border border-dark-border bg-dark-card p-5">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                      <Trophy className="h-5 w-5 text-neon-yellow" /> Recent Tournaments
                    </h3>
                    <button onClick={() => setActiveTab("tournaments")} className="text-xs text-neon-green hover:text-neon-green/80">View All →</button>
                  </div>
                  <div className="space-y-3">
                    {tournaments.slice(-5).reverse().map(t => (
                      <div key={t.id} className="flex items-center justify-between rounded-xl bg-dark-bg/50 p-3">
                        <div className="flex items-center gap-3">
                          <span className="text-xl">{t.game === "Free Fire" ? "🔥" : "🎯"}</span>
                          <div>
                            <div className="text-sm font-semibold text-white truncate max-w-[180px]">{t.title}</div>
                            <div className="text-xs text-gray-500">{t.prizePool} • {t.mode}</div>
                          </div>
                        </div>
                        <span className={`text-xs font-bold px-2 py-1 rounded-full ${
                          t.status === "live" ? "bg-neon-red/10 text-neon-red" : t.status === "filling" ? "bg-neon-yellow/10 text-neon-yellow" : t.status === "completed" ? "bg-gray-500/10 text-gray-500" : "bg-neon-blue/10 text-neon-blue"
                        }`}>
                          {t.status.toUpperCase()}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Quick Actions */}
              <div className="rounded-2xl border border-dark-border bg-dark-card p-5">
                <h3 className="text-lg font-bold text-white mb-4">⚡ Quick Actions</h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {[
                    { label: "Naya Tournament", icon: Plus, color: "from-neon-green to-emerald-500", action: () => { setActiveTab("tournaments"); setShowTournamentForm(true); } },
                    { label: "Users Dekho", icon: Eye, color: "from-neon-blue to-cyan-500", action: () => setActiveTab("users") },
                    { label: "Announcement", icon: Megaphone, color: "from-neon-purple to-pink-500", action: () => { setActiveTab("announcements"); setShowAnnouncementForm(true); } },
                    { label: "Settings", icon: Settings, color: "from-neon-yellow to-orange-500", action: () => setActiveTab("settings") },
                  ].map(a => (
                    <button key={a.label} onClick={a.action} className="flex flex-col items-center gap-2 rounded-xl border border-dark-border bg-dark-bg/50 p-4 hover:bg-dark-card-hover transition group">
                      <div className={`h-10 w-10 rounded-xl bg-gradient-to-br ${a.color} flex items-center justify-center group-hover:scale-110 transition`}>
                        <a.icon className="h-5 w-5 text-white" />
                      </div>
                      <span className="text-xs font-semibold text-gray-400 group-hover:text-white">{a.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TOURNAMENTS TAB */}
          {activeTab === "tournaments" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-bold text-white">All Tournaments ({tournaments.length})</h2>
                <button onClick={() => setShowTournamentForm(true)} className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-neon-green to-emerald-500 px-4 py-2.5 text-sm font-bold text-dark-bg hover:opacity-90 transition">
                  <Plus className="h-4 w-4" /> Naya Tournament
                </button>
              </div>

              {/* Tournament Form Modal */}
              {showTournamentForm && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
                  <div className="w-full max-w-lg rounded-2xl border border-dark-border bg-dark-card p-6 max-h-[90vh] overflow-y-auto">
                    <div className="flex items-center justify-between mb-6">
                      <h3 className="text-lg font-bold text-white">{editingTournament ? "✏️ Edit Tournament" : "➕ Naya Tournament Banao"}</h3>
                      <button onClick={resetTForm} className="p-1 text-gray-400 hover:text-white"><X className="h-5 w-5" /></button>
                    </div>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-gray-400 mb-1">Game</label>
                          <select value={tForm.game} onChange={e => setTForm({ ...tForm, game: e.target.value })} className="w-full rounded-xl border border-dark-border bg-dark-bg px-3 py-2.5 text-sm text-white focus:border-neon-green/50 focus:outline-none">
                            <option value="Free Fire">🔥 Free Fire</option>
                            <option value="PUBG Mobile">🎯 PUBG Mobile</option>
                            <option value="BGMI">🎮 BGMI</option>
                            <option value="COD Mobile">💀 COD Mobile</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-gray-400 mb-1">Status</label>
                          <select value={tForm.status} onChange={e => setTForm({ ...tForm, status: e.target.value as TournamentData["status"] })} className="w-full rounded-xl border border-dark-border bg-dark-bg px-3 py-2.5 text-sm text-white focus:border-neon-green/50 focus:outline-none">
                            <option value="upcoming">Upcoming</option>
                            <option value="filling">Filling</option>
                            <option value="live">Live</option>
                            <option value="completed">Completed</option>
                          </select>
                        </div>
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-gray-400 mb-1">Tournament Title</label>
                        <input value={tForm.title} onChange={e => setTForm({ ...tForm, title: e.target.value })} placeholder="e.g. Free Fire Squad Battle" className="w-full rounded-xl border border-dark-border bg-dark-bg px-3 py-2.5 text-sm text-white placeholder-gray-600 focus:border-neon-green/50 focus:outline-none" />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-gray-400 mb-1">Prize Pool</label>
                          <input value={tForm.prizePool} onChange={e => setTForm({ ...tForm, prizePool: e.target.value })} placeholder="₹10,000" className="w-full rounded-xl border border-dark-border bg-dark-bg px-3 py-2.5 text-sm text-white placeholder-gray-600 focus:border-neon-green/50 focus:outline-none" />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-gray-400 mb-1">Entry Fee</label>
                          <input value={tForm.entryFee} onChange={e => setTForm({ ...tForm, entryFee: e.target.value })} placeholder="FREE ya ₹50" className="w-full rounded-xl border border-dark-border bg-dark-bg px-3 py-2.5 text-sm text-white placeholder-gray-600 focus:border-neon-green/50 focus:outline-none" />
                        </div>
                      </div>
                      <div className="grid grid-cols-3 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-gray-400 mb-1">Max Players</label>
                          <input value={tForm.maxPlayers} onChange={e => setTForm({ ...tForm, maxPlayers: e.target.value })} placeholder="100" className="w-full rounded-xl border border-dark-border bg-dark-bg px-3 py-2.5 text-sm text-white placeholder-gray-600 focus:border-neon-green/50 focus:outline-none" />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-gray-400 mb-1">Mode</label>
                          <input value={tForm.mode} onChange={e => setTForm({ ...tForm, mode: e.target.value })} placeholder="Squad" className="w-full rounded-xl border border-dark-border bg-dark-bg px-3 py-2.5 text-sm text-white placeholder-gray-600 focus:border-neon-green/50 focus:outline-none" />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-gray-400 mb-1">Map</label>
                          <input value={tForm.map} onChange={e => setTForm({ ...tForm, map: e.target.value })} placeholder="Bermuda" className="w-full rounded-xl border border-dark-border bg-dark-bg px-3 py-2.5 text-sm text-white placeholder-gray-600 focus:border-neon-green/50 focus:outline-none" />
                        </div>
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-gray-400 mb-1">Time</label>
                        <input value={tForm.time} onChange={e => setTForm({ ...tForm, time: e.target.value })} placeholder="e.g. Starts in 1 hr" className="w-full rounded-xl border border-dark-border bg-dark-bg px-3 py-2.5 text-sm text-white placeholder-gray-600 focus:border-neon-green/50 focus:outline-none" />
                      </div>
                      <div className="flex gap-3 pt-2">
                        <button onClick={resetTForm} className="flex-1 rounded-xl border border-dark-border py-2.5 text-sm font-medium text-gray-400 hover:text-white transition">Cancel</button>
                        <button onClick={handleSaveTournament} className="flex-1 rounded-xl bg-gradient-to-r from-neon-green to-emerald-500 py-2.5 text-sm font-bold text-dark-bg hover:opacity-90 transition">
                          {editingTournament ? "Update Karo" : "Create Karo"} 🚀
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Tournaments List */}
              <div className="space-y-3">
                {tournaments.map(t => (
                  <div key={t.id} className="flex flex-col sm:flex-row sm:items-center justify-between rounded-2xl border border-dark-border bg-dark-card p-4 hover:bg-dark-card-hover transition gap-4">
                    <div className="flex items-center gap-4">
                      <span className="text-3xl">{t.game === "Free Fire" ? "🔥" : t.game === "PUBG Mobile" ? "🎯" : t.game === "BGMI" ? "🎮" : "💀"}</span>
                      <div>
                        <div className="text-base font-bold text-white">{t.title}</div>
                        <div className="flex items-center gap-3 text-xs text-gray-500 mt-1">
                          <span>{t.game}</span>
                          <span>•</span>
                          <span>{t.mode} • {t.map}</span>
                          <span>•</span>
                          <span className="text-neon-yellow font-semibold">{t.prizePool}</span>
                          <span>•</span>
                          <span>{t.entryFee}</span>
                        </div>
                        <div className="flex items-center gap-3 text-xs text-gray-500 mt-1">
                          <span className="flex items-center gap-1"><Users className="h-3 w-3" /> {t.currentPlayers}/{t.maxPlayers}</span>
                          <span className="flex items-center gap-1"><Calendar className="h-3 w-3" /> {t.time}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 self-end sm:self-center">
                      <span className={`text-xs font-bold px-3 py-1 rounded-full ${
                        t.status === "live" ? "bg-neon-red/10 text-neon-red border border-neon-red/20" : t.status === "filling" ? "bg-neon-yellow/10 text-neon-yellow border border-neon-yellow/20" : t.status === "completed" ? "bg-gray-500/10 text-gray-500 border border-gray-500/20" : "bg-neon-blue/10 text-neon-blue border border-neon-blue/20"
                      }`}>
                        {t.status.toUpperCase()}
                      </span>
                      <button onClick={() => handleEditTournament(t)} className="p-2 rounded-lg text-neon-blue hover:bg-neon-blue/10 transition">
                        <Edit3 className="h-4 w-4" />
                      </button>
                      <button onClick={() => deleteTournament(t.id)} className="p-2 rounded-lg text-neon-red hover:bg-neon-red/10 transition">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
                {tournaments.length === 0 && (
                  <div className="text-center py-12 text-gray-500">
                    <Trophy className="h-12 w-12 mx-auto mb-3 text-gray-700" />
                    <p>Koi tournament nahi hai. Naya banao! 🏆</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* USERS TAB */}
          {activeTab === "users" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-bold text-white">All Registered Users ({registeredUsers.length})</h2>
              </div>

              <div className="rounded-2xl border border-dark-border bg-dark-card overflow-hidden">
                {/* Table Header */}
                <div className="grid grid-cols-12 gap-2 px-4 sm:px-6 py-3 bg-dark-bg/50 text-xs font-semibold text-gray-500 uppercase tracking-wider border-b border-dark-border">
                  <div className="col-span-1 text-center">#</div>
                  <div className="col-span-3">Name</div>
                  <div className="col-span-4">Email</div>
                  <div className="col-span-2 text-center">Joined</div>
                  <div className="col-span-2 text-center">Status</div>
                </div>
                {registeredUsers.map((u, i) => (
                  <div key={u.email} className="grid grid-cols-12 gap-2 px-4 sm:px-6 py-4 items-center border-b border-dark-border/50 hover:bg-dark-card-hover transition">
                    <div className="col-span-1 text-center text-sm font-bold text-gray-500">{i + 1}</div>
                    <div className="col-span-3 flex items-center gap-2">
                      <div className="h-8 w-8 rounded-full bg-gradient-to-br from-neon-green to-neon-blue flex items-center justify-center text-dark-bg text-xs font-bold">{u.name.charAt(0)}</div>
                      <span className="text-sm font-semibold text-white truncate">{u.name}</span>
                    </div>
                    <div className="col-span-4 text-sm text-gray-400 truncate">{u.email}</div>
                    <div className="col-span-2 text-center text-xs text-gray-500">{u.joinedAt}</div>
                    <div className="col-span-2 text-center">
                      <span className="text-xs font-bold bg-neon-green/10 text-neon-green px-2 py-1 rounded-full">Active</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ANNOUNCEMENTS TAB */}
          {activeTab === "announcements" && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-bold text-white">Announcements ({announcements.length})</h2>
                <button onClick={() => setShowAnnouncementForm(true)} className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-neon-purple to-neon-blue px-4 py-2.5 text-sm font-bold text-white hover:opacity-90 transition">
                  <Plus className="h-4 w-4" /> Naya Announcement
                </button>
              </div>

              {/* Announcement Form Modal */}
              {showAnnouncementForm && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
                  <div className="w-full max-w-md rounded-2xl border border-dark-border bg-dark-card p-6">
                    <div className="flex items-center justify-between mb-6">
                      <h3 className="text-lg font-bold text-white">📢 Naya Announcement</h3>
                      <button onClick={() => setShowAnnouncementForm(false)} className="p-1 text-gray-400 hover:text-white"><X className="h-5 w-5" /></button>
                    </div>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-xs font-semibold text-gray-400 mb-1">Title</label>
                        <input value={aForm.title} onChange={e => setAForm({ ...aForm, title: e.target.value })} placeholder="Announcement title" className="w-full rounded-xl border border-dark-border bg-dark-bg px-3 py-2.5 text-sm text-white placeholder-gray-600 focus:border-neon-purple/50 focus:outline-none" />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-gray-400 mb-1">Message</label>
                        <textarea value={aForm.message} onChange={e => setAForm({ ...aForm, message: e.target.value })} placeholder="Message likhiye..." rows={3} className="w-full rounded-xl border border-dark-border bg-dark-bg px-3 py-2.5 text-sm text-white placeholder-gray-600 focus:border-neon-purple/50 focus:outline-none resize-none" />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-gray-400 mb-1">Type</label>
                        <select value={aForm.type} onChange={e => setAForm({ ...aForm, type: e.target.value as Announcement["type"] })} className="w-full rounded-xl border border-dark-border bg-dark-bg px-3 py-2.5 text-sm text-white focus:border-neon-purple/50 focus:outline-none">
                          <option value="info">ℹ️ Info</option>
                          <option value="warning">⚠️ Warning</option>
                          <option value="success">✅ Success</option>
                        </select>
                      </div>
                      <div className="flex gap-3 pt-2">
                        <button onClick={() => setShowAnnouncementForm(false)} className="flex-1 rounded-xl border border-dark-border py-2.5 text-sm font-medium text-gray-400 hover:text-white transition">Cancel</button>
                        <button onClick={handleSaveAnnouncement} className="flex-1 rounded-xl bg-gradient-to-r from-neon-purple to-neon-blue py-2.5 text-sm font-bold text-white hover:opacity-90 transition">
                          Publish Karo 📢
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Announcements List */}
              <div className="space-y-3">
                {announcements.map(a => (
                  <div key={a.id} className={`rounded-2xl border p-5 ${
                    a.type === "success" ? "border-neon-green/20 bg-neon-green/5" : a.type === "warning" ? "border-neon-yellow/20 bg-neon-yellow/5" : "border-neon-blue/20 bg-neon-blue/5"
                  }`}>
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-lg">{a.type === "success" ? "✅" : a.type === "warning" ? "⚠️" : "ℹ️"}</span>
                          <h4 className="text-base font-bold text-white">{a.title}</h4>
                          <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                            a.type === "success" ? "bg-neon-green/10 text-neon-green" : a.type === "warning" ? "bg-neon-yellow/10 text-neon-yellow" : "bg-neon-blue/10 text-neon-blue"
                          }`}>{a.type.toUpperCase()}</span>
                        </div>
                        <p className="text-sm text-gray-400">{a.message}</p>
                        <span className="text-xs text-gray-600 mt-2 inline-block">{a.createdAt}</span>
                      </div>
                      <button onClick={() => deleteAnnouncement(a.id)} className="p-2 rounded-lg text-neon-red hover:bg-neon-red/10 transition">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
                {announcements.length === 0 && (
                  <div className="text-center py-12 text-gray-500">
                    <Megaphone className="h-12 w-12 mx-auto mb-3 text-gray-700" />
                    <p>Koi announcement nahi hai. Naya banao! 📢</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* SETTINGS TAB */}
          {activeTab === "settings" && (
            <div className="space-y-6">
              <div className="rounded-2xl border border-dark-border bg-dark-card p-6">
                <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                  <Settings className="h-5 w-5 text-neon-green" /> General Settings
                </h3>
                <div className="space-y-5">
                  <div className="flex items-center justify-between p-4 rounded-xl bg-dark-bg/50 border border-dark-border">
                    <div>
                      <div className="text-sm font-semibold text-white">Platform Name</div>
                      <div className="text-xs text-gray-500">Tournament platform ka naam</div>
                    </div>
                    <span className="text-sm text-neon-green font-bold">BattleZone</span>
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-xl bg-dark-bg/50 border border-dark-border">
                    <div>
                      <div className="text-sm font-semibold text-white">Admin Email</div>
                      <div className="text-xs text-gray-500">Admin login email</div>
                    </div>
                    <span className="text-sm text-gray-400">{user.email}</span>
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-xl bg-dark-bg/50 border border-dark-border">
                    <div>
                      <div className="text-sm font-semibold text-white">Maintenance Mode</div>
                      <div className="text-xs text-gray-500">Platform temporarily band karo</div>
                    </div>
                    <div className="h-6 w-11 rounded-full bg-dark-border relative cursor-pointer">
                      <div className="absolute top-1 left-1 h-4 w-4 rounded-full bg-gray-500 transition"></div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-xl bg-dark-bg/50 border border-dark-border">
                    <div>
                      <div className="text-sm font-semibold text-white">New Registration</div>
                      <div className="text-xs text-gray-500">Naye users ko register hone do</div>
                    </div>
                    <div className="h-6 w-11 rounded-full bg-neon-green/20 relative cursor-pointer">
                      <div className="absolute top-1 right-1 h-4 w-4 rounded-full bg-neon-green transition"></div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-xl bg-dark-bg/50 border border-dark-border">
                    <div>
                      <div className="text-sm font-semibold text-white">Auto Tournament Create</div>
                      <div className="text-xs text-gray-500">Automatically daily tournaments banao</div>
                    </div>
                    <div className="h-6 w-11 rounded-full bg-neon-green/20 relative cursor-pointer">
                      <div className="absolute top-1 right-1 h-4 w-4 rounded-full bg-neon-green transition"></div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Danger Zone */}
              <div className="rounded-2xl border border-neon-red/20 bg-neon-red/5 p-6">
                <h3 className="text-lg font-bold text-neon-red mb-4">⚠️ Danger Zone</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-4 rounded-xl bg-dark-bg/50 border border-dark-border">
                    <div>
                      <div className="text-sm font-semibold text-white">Reset All Data</div>
                      <div className="text-xs text-gray-500">Saara data delete ho jayega</div>
                    </div>
                    <button className="rounded-lg bg-neon-red/10 border border-neon-red/20 px-4 py-2 text-xs font-bold text-neon-red hover:bg-neon-red/20 transition">Reset</button>
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-xl bg-dark-bg/50 border border-dark-border">
                    <div>
                      <div className="text-sm font-semibold text-white">Delete All Users</div>
                      <div className="text-xs text-gray-500">Saare users delete ho jayenge</div>
                    </div>
                    <button className="rounded-lg bg-neon-red/10 border border-neon-red/20 px-4 py-2 text-xs font-bold text-neon-red hover:bg-neon-red/20 transition">Delete</button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
