import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { Gamepad2, Mail, Lock, Eye, EyeOff, LogIn, ShieldCheck, ArrowLeft } from "lucide-react";

export function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!email || !password) {
      setError("Sab fields bharna zaroori hai!");
      return;
    }
    setLoading(true);
    setTimeout(() => {
      const result = login(email, password);
      setLoading(false);
      if (result.success) {
        if (result.isAdmin) {
          navigate("/admin");
        } else {
          navigate("/");
        }
      } else {
        setError(result.message);
      }
    }, 800);
  };

  return (
    <div className="min-h-screen bg-dark-bg flex items-center justify-center relative overflow-hidden">
      {/* BG Effects */}
      <div className="absolute top-1/4 left-1/4 h-96 w-96 rounded-full bg-neon-green/5 blur-[120px]"></div>
      <div className="absolute bottom-1/4 right-1/4 h-96 w-96 rounded-full bg-neon-blue/5 blur-[120px]"></div>
      <div className="absolute inset-0 bg-[linear-gradient(rgba(57,255,20,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(57,255,20,0.03)_1px,transparent_1px)] bg-[size:60px_60px]"></div>

      <div className="relative z-10 w-full max-w-md mx-4">
        {/* Back to Home */}
        <Link to="/" className="inline-flex items-center gap-2 text-gray-400 hover:text-neon-green transition mb-6 text-sm">
          <ArrowLeft className="h-4 w-4" /> Home pe wapas jao
        </Link>

        <div className="rounded-2xl border border-dark-border bg-dark-card p-8 shadow-2xl">
          {/* Logo */}
          <div className="text-center mb-8">
            <div className="inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-neon-green to-neon-blue mx-auto mb-4 animate-float">
              <Gamepad2 className="h-8 w-8 text-dark-bg" />
            </div>
            <h1 className="text-2xl font-black text-white">
              BATTLE<span className="text-neon-green">ZONE</span>
            </h1>
            <p className="text-gray-400 text-sm mt-1">Apne account mein login karo 🎮</p>
          </div>

          {/* Admin Hint */}
          <div className="rounded-xl bg-neon-purple/5 border border-neon-purple/20 p-3 mb-6">
            <div className="flex items-center gap-2 text-neon-purple text-xs font-semibold mb-1">
              <ShieldCheck className="h-4 w-4" /> Admin Login
            </div>
            <p className="text-gray-500 text-xs">Admin panel access ke liye admin credentials use karo.</p>
          </div>

          {/* Error */}
          {error && (
            <div className="rounded-xl bg-neon-red/10 border border-neon-red/20 p-3 mb-6 text-sm text-neon-red font-medium">
              ❌ {error}
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label className="block text-sm font-semibold text-gray-300 mb-2">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-500" />
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="tumhara@email.com"
                  className="w-full rounded-xl border border-dark-border bg-dark-bg pl-11 pr-4 py-3 text-white placeholder-gray-600 focus:border-neon-green/50 focus:outline-none focus:ring-1 focus:ring-neon-green/30 transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-300 mb-2">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-500" />
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full rounded-xl border border-dark-border bg-dark-bg pl-11 pr-11 py-3 text-white placeholder-gray-600 focus:border-neon-green/50 focus:outline-none focus:ring-1 focus:ring-neon-green/30 transition"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
                >
                  {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 text-sm text-gray-400 cursor-pointer">
                <input type="checkbox" className="rounded border-dark-border bg-dark-bg text-neon-green focus:ring-neon-green/30" />
                Remember me
              </label>
              <a href="#" className="text-sm text-neon-green hover:text-neon-green/80 transition">Forgot Password?</a>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-neon-green to-emerald-500 py-3.5 text-base font-bold text-dark-bg transition hover:opacity-90 disabled:opacity-60 animate-pulse-glow"
            >
              {loading ? (
                <div className="h-5 w-5 border-2 border-dark-bg border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <>
                  <LogIn className="h-5 w-5" />
                  Login Karo
                </>
              )}
            </button>
          </form>

          {/* Signup Link */}
          <div className="mt-6 text-center">
            <p className="text-gray-500 text-sm">
              Account nahi hai?{" "}
              <Link to="/signup" className="text-neon-green font-semibold hover:text-neon-green/80 transition">
                Signup Karo →
              </Link>
            </p>
          </div>

          {/* Divider */}
          <div className="my-6 flex items-center gap-3">
            <div className="flex-1 h-px bg-dark-border"></div>
            <span className="text-xs text-gray-600">OR</span>
            <div className="flex-1 h-px bg-dark-border"></div>
          </div>

          {/* Social login buttons */}
          <div className="grid grid-cols-2 gap-3">
            <button className="flex items-center justify-center gap-2 rounded-xl border border-dark-border py-2.5 text-sm font-medium text-gray-400 hover:border-neon-blue/30 hover:text-white transition">
              📱 Google
            </button>
            <button className="flex items-center justify-center gap-2 rounded-xl border border-dark-border py-2.5 text-sm font-medium text-gray-400 hover:border-neon-blue/30 hover:text-white transition">
              📘 Facebook
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
