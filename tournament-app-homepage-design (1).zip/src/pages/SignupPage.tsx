import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { Gamepad2, Mail, Lock, Eye, EyeOff, UserPlus, User, ArrowLeft, Check } from "lucide-react";

export function SignupPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { signup } = useAuth();
  const navigate = useNavigate();

  const passwordStrength = () => {
    if (password.length === 0) return { level: 0, text: "", color: "" };
    if (password.length < 4) return { level: 1, text: "Weak 😟", color: "bg-neon-red" };
    if (password.length < 8) return { level: 2, text: "Medium 🤔", color: "bg-neon-yellow" };
    return { level: 3, text: "Strong 💪", color: "bg-neon-green" };
  };

  const strength = passwordStrength();

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!name || !email || !password || !confirmPassword) {
      setError("Sab fields bharna zaroori hai!");
      return;
    }
    if (password.length < 6) {
      setError("Password kam se kam 6 characters ka hona chahiye!");
      return;
    }
    if (password !== confirmPassword) {
      setError("Dono passwords match nahi ho rahe!");
      return;
    }

    setLoading(true);
    setTimeout(() => {
      const result = signup(name, email, password);
      setLoading(false);
      if (result.success) {
        navigate("/");
      } else {
        setError(result.message);
      }
    }, 800);
  };

  return (
    <div className="min-h-screen bg-dark-bg flex items-center justify-center relative overflow-hidden py-8">
      {/* BG Effects */}
      <div className="absolute top-1/4 right-1/4 h-96 w-96 rounded-full bg-neon-purple/5 blur-[120px]"></div>
      <div className="absolute bottom-1/4 left-1/4 h-96 w-96 rounded-full bg-neon-green/5 blur-[120px]"></div>
      <div className="absolute inset-0 bg-[linear-gradient(rgba(176,38,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(176,38,255,0.03)_1px,transparent_1px)] bg-[size:60px_60px]"></div>

      <div className="relative z-10 w-full max-w-md mx-4">
        {/* Back to Home */}
        <Link to="/" className="inline-flex items-center gap-2 text-gray-400 hover:text-neon-green transition mb-6 text-sm">
          <ArrowLeft className="h-4 w-4" /> Home pe wapas jao
        </Link>

        <div className="rounded-2xl border border-dark-border bg-dark-card p-8 shadow-2xl">
          {/* Logo */}
          <div className="text-center mb-8">
            <div className="inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-neon-purple to-neon-blue mx-auto mb-4 animate-float">
              <Gamepad2 className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-2xl font-black text-white">
              Join BATTLE<span className="text-neon-green">ZONE</span>
            </h1>
            <p className="text-gray-400 text-sm mt-1">Apna gaming account banao 🎮🔥</p>
          </div>

          {/* Features */}
          <div className="rounded-xl bg-neon-green/5 border border-neon-green/20 p-3 mb-6">
            <div className="grid grid-cols-2 gap-2">
              {["Free Tournaments", "Daily Prizes", "Instant Payout", "24/7 Support"].map(f => (
                <div key={f} className="flex items-center gap-1.5 text-xs text-gray-400">
                  <Check className="h-3 w-3 text-neon-green" /> {f}
                </div>
              ))}
            </div>
          </div>

          {/* Error */}
          {error && (
            <div className="rounded-xl bg-neon-red/10 border border-neon-red/20 p-3 mb-6 text-sm text-neon-red font-medium">
              ❌ {error}
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSignup} className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-gray-300 mb-2">Full Name</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-500" />
                <input
                  type="text"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="Tumhara naam"
                  className="w-full rounded-xl border border-dark-border bg-dark-bg pl-11 pr-4 py-3 text-white placeholder-gray-600 focus:border-neon-purple/50 focus:outline-none focus:ring-1 focus:ring-neon-purple/30 transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-300 mb-2">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-500" />
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="tumhara@email.com"
                  className="w-full rounded-xl border border-dark-border bg-dark-bg pl-11 pr-4 py-3 text-white placeholder-gray-600 focus:border-neon-purple/50 focus:outline-none focus:ring-1 focus:ring-neon-purple/30 transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-300 mb-2">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-500" />
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="Kam se kam 6 characters"
                  className="w-full rounded-xl border border-dark-border bg-dark-bg pl-11 pr-11 py-3 text-white placeholder-gray-600 focus:border-neon-purple/50 focus:outline-none focus:ring-1 focus:ring-neon-purple/30 transition"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
                >
                  {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
              {/* Password Strength */}
              {password.length > 0 && (
                <div className="mt-2">
                  <div className="flex gap-1 mb-1">
                    {[1, 2, 3].map(i => (
                      <div key={i} className={`h-1.5 flex-1 rounded-full ${i <= strength.level ? strength.color : "bg-dark-border"} transition-all`}></div>
                    ))}
                  </div>
                  <span className="text-xs text-gray-500">{strength.text}</span>
                </div>
              )}
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-300 mb-2">Confirm Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-500" />
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={e => setConfirmPassword(e.target.value)}
                  placeholder="Password dubara daalo"
                  className="w-full rounded-xl border border-dark-border bg-dark-bg pl-11 pr-4 py-3 text-white placeholder-gray-600 focus:border-neon-purple/50 focus:outline-none focus:ring-1 focus:ring-neon-purple/30 transition"
                />
                {confirmPassword.length > 0 && password === confirmPassword && (
                  <Check className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-neon-green" />
                )}
              </div>
            </div>

            <div className="flex items-start gap-2 text-sm text-gray-400">
              <input type="checkbox" className="mt-1 rounded border-dark-border bg-dark-bg" defaultChecked />
              <span>Main <a href="#" className="text-neon-purple hover:text-neon-purple/80">Terms & Conditions</a> aur <a href="#" className="text-neon-purple hover:text-neon-purple/80">Privacy Policy</a> se agree karta/karti hoon.</span>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-neon-purple to-neon-blue py-3.5 text-base font-bold text-white transition hover:opacity-90 disabled:opacity-60"
            >
              {loading ? (
                <div className="h-5 w-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <>
                  <UserPlus className="h-5 w-5" />
                  Account Banao 🚀
                </>
              )}
            </button>
          </form>

          {/* Login Link */}
          <div className="mt-6 text-center">
            <p className="text-gray-500 text-sm">
              Pehle se account hai?{" "}
              <Link to="/login" className="text-neon-green font-semibold hover:text-neon-green/80 transition">
                Login Karo →
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
